package LoginModule;

import java.util.Scanner;

public class LoginPage {
	public User displaylogin()
	{
		Scanner sc=new Scanner(System.in);
		int flag=0;
		AddUsers au=new AddUsers();
		au.loadusers();
		User sendUser=null;
		
		
		while(flag!=1)
		{
			System.out.println("ENTER THE USERNAME:");
			String uname=sc.nextLine();
			System.out.println("ENTER THE PASSWORD");
			String upass=sc.nextLine();
			for(User u: au.userlist)
			{
				if(u.getUsername().equals(uname) && u.getPassword().equals(upass))
				{
					System.out.println("LOGIN SUCCESSFULL!");
					System.out.println("\n");
					flag=1;
					sendUser=u;
					break;
					
				}
			}
			if(flag==1)
			{
				break;
			}
			else
			{
				System.out.println("INVALID USERNAME OR PASSWORD! TRY AGAIN");
				System.out.println("\n");
			}
		}
		
		return sendUser;
	}
}
