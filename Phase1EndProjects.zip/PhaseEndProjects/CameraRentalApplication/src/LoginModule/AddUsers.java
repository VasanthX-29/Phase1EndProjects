package LoginModule;

import java.util.ArrayList;

public class AddUsers {
	 public ArrayList<User> userlist =new ArrayList<User>();
	 
	public void loadusers()
	{
	    
		 User u1=new User();
		 
		 u1.setUsername("vas@gmail.com");
		 u1.setPassword("123");
		 u1.setValletAmount(2000);
		 
		 User u2=new User();
		 
		 u2.setUsername("kiran@yahoo.com");
		 u2.setPassword("456");
		 u2.setValletAmount(5000);
		 
		 userlist.add(u1);
		 userlist.add(u2);
		 
		 
	}
	

}
