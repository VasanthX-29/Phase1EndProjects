package LoginModule;

public class User {

	   String username;
	   String password;
	   double valletAmount;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getValletAmount() {
		return valletAmount;
	}
	public void setValletAmount(double valletAmount) {
		this.valletAmount = valletAmount;
	}
	   

}
