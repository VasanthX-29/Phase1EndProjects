package LoginModule;

public class LoginMain {

	public User triggerlogin()
	{
		LoginPage lp=new LoginPage();
		User u=lp.displaylogin();
		return u;
	}

}
