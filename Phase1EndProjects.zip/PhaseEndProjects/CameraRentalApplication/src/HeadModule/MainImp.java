package HeadModule;
import java.util.Scanner;
import StoreCameraModule.*;
import StoreCameraModule.*;

import LoginModule.LoginMain;
import LoginModule.User;
public class MainImp {
	
	public static void main(String[] args) {
		System.out.println("+------------------------------+");
		System.out.println("| WELCOME TO CAMERA RENTAL APP |");
		System.out.println("+------------------------------+");
		Scanner sc=new Scanner(System.in);
		LoginMain lm=new LoginMain();
		User u=lm.triggerlogin();   //triggers login authentication
		StoreCameraMain scm=new StoreCameraMain();
		scm.storecameras();  //triggered to store some default cameras
		
		
		
	   
		while(true)   //displays main menu
		{
			 int ch;
			System.out.println("\n");
			System.out.println("\tMAIN MENU ");
			System.out.println("1. MY CAMERA");
			System.out.println("2. RENT A CAMERA");
			System.out.println("3. VIEW ALL CAMERAS");
			System.out.println("4. MY VALLET");
			System.out.println("5. EXIT");
			System.out.println("\n");
			
			System.out.println("ENTER THE CHOICE: ");
			ch=sc.nextInt();
			System.out.println("\n");
			
			switch(ch)
			{
			case 1:
				scm.cameraManagement();
				break;
			case 2:
				rentimp(u,scm);
				break;
			case 3:
				viewallcamera(scm);
				break;
			case 4:
				 valletImp(u);
				 break;
			case 5:
				System.out.println("THANKS FOR CONNECTING WITH US !");
				System.exit(0);
			default:
				System.out.println("INVALID CHOICE! CHOOSE A VALID CHOICE");
				System.out.println("\n");
			}
		}
		

	}
	
	public static void rentimp(User u, StoreCameraMain scm)   //rental implementation
	{
		
		int camid=0;
		int checkid=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERAS");
		System.out.println("==================================================================================");
		System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", "CAMERA ID", "BRAND", "MODEL","PRICE/DAY","STATUS");
		System.out.println("==================================================================================");
	    for(Camera c: scm.cameralist)
	    {
	    	System.out.printf("%-15d %-15s %-15s %-15s %-15s%n",c.getId() , c.getBrand(), c.getModel(),c.getPrice(),c.getStatus());

	    	
	    	System.out.println();
	    }
	    System.out.println("==================================================================================");
	 
	    Camera torent=null;
	    String status="";
	    System.out.println("ENTER THE CAMERA ID YOU WANT TO RENT");
	    try
	    {
	    	  camid=sc.nextInt();
	    	  for( Camera c: scm.cameralist)  //checks if ID is present or not
				{
					if(c.getId()==camid)    
					{
						torent=c;
						checkid=1;
						status=torent.getStatus();
						break;
					}
				}
		if(checkid==0)
		{
			System.out.println("YOU HAVE ENTERED A WRONG ID");
		}
		else if(status.equals("RENTED"))          //verifies whether the camera has already been rented
		{
			System.out.println("THE CAMERA YOU SELECTED HAS ALREADY BEEN RENTED");
		}
		else
		{
			
			double uservallet=u.getValletAmount();
			double priceofcam=torent.getPrice();
			
			if(uservallet>=priceofcam)
			{
				u.setValletAmount(uservallet-priceofcam);     //deducts amount from the user Wallet.
				System.out.println("YOUR TRANSACTION FOR CAMERA - "+torent.getBrand()+" "+
				torent.getModel()+" "+"WITH RENT INR."+torent.getPrice()+" HAS SUCCESSFULLY COMPLETED");
				
					 for( Camera c: scm.cameralist)
						{
							if(camid==c.getId())
							{
								c.setStatus("RENTED");   //Changes the status to rented
							}
						}
				    
				System.out.println("\n");
				
			}
			else
			{
				System.out.println("ERROR: TRANSACTION FAILED DUE TO INSUFFICIENT BALANCE");
				System.out.println("\n");
			}
      
		}
	    	 
				
	    }
	    catch(Exception e)
	    {
	    	System.out.println("OOPS!YOU ENTERED AN INVALID ID");
	    }
	  
	    
	  
			
	}
	
	public static void viewallcamera(StoreCameraMain scm)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("CAMERAS LIST : ");
		System.out.println("==================================================================================");
		System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", "CAMERA ID", "BRAND", "MODEL","PRICE/DAY","STATUS");
		System.out.println("==================================================================================");
	    for(Camera c: scm.cameralist)
	    {
	    	
	    	 System.out.printf("%-15d %-15s %-15s %-15s %-15s%n",c.getId() , c.getBrand(), c.getModel(),c.getPrice(),c.getStatus());

	    	
	    	System.out.println();
	    }
	    System.out.println("==================================================================================");
	}
	
	public static void valletImp(User u) //wallet implementation
	{
		
		int ch;
		Scanner sc=new Scanner(System.in);
		System.out.println("YOUR CURRENT WALLET BALANCE IS INR."+u.getValletAmount());   //displays current wallet balance
		System.out.println("DO YOU WANT TO DEPOSIT ? (1.Yes 2. No)");
		ch=sc.nextInt();
		if(ch==1)
		{
			System.out.println("ENTER THE AMOUNT: ");
			double amt=sc.nextDouble();
			u.setValletAmount(u.getValletAmount()+amt);
			System.out.println("YOUR WALLET HAS BEEN UPDATED");
			System.out.println("CURRENT WALLET BALANCE: "+u.getValletAmount());
			System.out.println("\n");
		}
		else
		{
			System.out.println("\n");
			return;
		}
		
		
	}

}
