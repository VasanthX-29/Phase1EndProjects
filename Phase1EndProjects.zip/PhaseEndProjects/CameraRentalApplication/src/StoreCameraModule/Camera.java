package StoreCameraModule;

public class Camera {
	static int cameracount=100;
    int id;
	String brand;
	String Model;
	double price;
	String status="AVAILABLE";
	public int getId() {
		return id;
	}
	
	public void setId() {
		cameracount++;
		this.id = cameracount;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return Model;
	}
	public void setModel(String model) {
		Model = model;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
