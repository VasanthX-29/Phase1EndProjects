package StoreCameraModule;

import java.util.ArrayList;
import java.util.Scanner;

public class StoreCameraMain {
	
	public ArrayList <Camera> cameralist=new ArrayList<Camera>();
	
	
	public void storecameras() {
		 Camera c1=new Camera();
		 c1.setId();
		 c1.setBrand("Samsung");
		 c1.setModel("DS123");
		 c1.setPrice(1000);
		 c1.setStatus("AVAILABLE");
		 
		 cameralist.add(c1);
		 
		 Camera c2=new Camera();
		 c2.setId();
		 c2.setBrand("Sony");
		 c2.setModel("HD123");
		 c2.setPrice(5000);
		 c2.setStatus("AVAILABLE");
		 
		 cameralist.add(c2);
		 
		 Camera c3=new Camera();
		 c3.setId();
		 c3.setBrand("LG");
		 c3.setModel("L1447");
		 c3.setPrice(500);
		 c3.setStatus("AVAILABLE");
		 
		 cameralist.add(c3);
		 
		 Camera c4=new Camera();
		 c4.setId();
		 c4.setBrand("Canon");
		 c4.setModel("5050");
		 c4.setPrice(2500);
		 c4.setStatus("AVAILABLE");
		 
		 cameralist.add(c4);
		 
		 Camera c5=new Camera();
		 c5.setId();
		 c5.setBrand("Chroma");
		 c5.setModel("XPL");
		 c5.setPrice(3000);
		 c5.setStatus("AVAILABLE");
		 
		 cameralist.add(c5);
	}
	public void cameraManagement()
	{
		Scanner sc=new Scanner(System.in);
	
		
		while(true)
		{
			int choice;
			System.out.println("\tSUB MENU ");
			System.out.println("1. ADD");
			System.out.println("2. REMOVE");
			System.out.println("3. VIEW MY CAMERAS");
			System.out.println("4. GO TO PREVIOUS MENU");
			System.out.println("\n");
			System.out.println("ENTER YOUR OPTION: ");
			choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
				addcamera();
				break;
			case 2:
				removecamera();
				break;
			case 3:
				viewcamera();
				break;
			case 4:
				return;
			default:
				System.out.println("INVALID CHOICE! CHOOSE A VALID CHOICE");
			
			}
			
		}
	}
	
	

	public void addcamera()
	{
		Scanner sc=new Scanner(System.in);
		Camera c=new Camera();
	
		
		System.out.println("ENTER THE BRAND NAME: ");
		c.setBrand(sc.next());
		System.out.println("ENTER THE BRAND MODEL: ");
		c.setModel(sc.next());
		System.out.println("ENTER THE PRICE/DAY: ");
		try
		{
			 c.setPrice(sc.nextDouble());
			 c.setId();
			 c.setStatus("AVAILABLE");
			    cameralist.add(c);
			    System.out.println("\n");
				System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST \n");
		}
		catch(Exception e)
		{
			System.out.println("INVALID PRICE VALUE ENTERED. PLEASE ADD CAMERA DETAILS AGAIN");
			System.out.println("\n");
		}
	   
	}
	public void removecamera()
	{
		Scanner sc=new Scanner(System.in);
		int checkid=0;
		System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERAS");
		System.out.println("==================================================================================");
		System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", "CAMERA ID", "BRAND", "MODEL","PRICE/DAY","STATUS");
		System.out.println("==================================================================================");
	    for(Camera c: cameralist)
	    {
	    	System.out.printf("%-15d %-15s %-15s %-15s %-15s%n",c.getId() , c.getBrand(), c.getModel(),c.getPrice(),c.getStatus());

	    	
	    	System.out.println();
	    }
	    System.out.println("==================================================================================");
		int id;
		System.out.println("ENTER THE CAMERA ID TO REMOVE:");
		try
		{
			id=sc.nextInt();
			Camera todelete=null;
			for( Camera c: cameralist)
			{
				if(c.getId()==id)
				{
					todelete=c;
					checkid=1;
					break;
				}
			}
			if(checkid==0)
			{
				System.out.println("WRONG ID ENTERED! PLEASE PROVIDE A VALID ID ");
			}
			else
			{
				cameralist.remove(todelete);
				System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST ");
				System.out.println("\n");
			}
			
		}
		catch(Exception e)
		{
			System.out.println("OOPS! YOU HAVE ENTERED A INVALID ID VALUE");
			System.out.println("\n");
		}
		
		
		
	}
	
	public void viewcamera()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERAS");
		System.out.println("==================================================================================");
		System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", "CAMERA ID", "BRAND", "MODEL","PRICE/DAY","STATUS");
		System.out.println("==================================================================================");
	    for(Camera c: cameralist)
	    {
	    	System.out.printf("%-15d %-15s %-15s %-15s %-15s%n",c.getId() , c.getBrand(), c.getModel(),c.getPrice(),c.getStatus());

	    	
	    	System.out.println();
	    }
	    System.out.println("==================================================================================");
	}

}
